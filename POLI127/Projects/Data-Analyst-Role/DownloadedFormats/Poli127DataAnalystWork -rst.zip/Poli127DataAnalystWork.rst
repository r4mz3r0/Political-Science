
.. code:: ipython3

    cd C:\Users\Ramiro Gonzalez\Desktop\POLI127DATA\json files


.. parsed-literal::

    C:\Users\Ramiro Gonzalez\Desktop\POLI127DATA\json files
    

POLI 127 Data Analyst Role
==========================

Ramiro Gonzalez and Melissa Becerra
-----------------------------------

.. code:: ipython3

    import pandas as pd
    import matplotlib.pyplot as plt
    import numpy as np
    import csv
    import json
    from IPython.display import Image
    import math
    from pandas import DataFrame as df
    from scipy.stats import trim_mean, kurtosis
    from scipy.stats.mstats import mode, gmean, hmean
    from scipy import interpolate

METADATA
========

Link
====

https://github.com/impracticaldev/Political-Science/tree/master/POLI127/Projects/Data-Analyst-Role
## Curated data Independent Variable 1: Income\_same\_sex\_couple to be
determined. Independent Variable 2 (NOTE: This may be used as variable):
Same\_sex\_couple\_who\_are\_same\_sex\_spouses\_for\_years\_2005\_2016
was original in percentage, it was converted to quantity by using
:math:`FLOOR((x,y)\cdot(x_2,y_2))` Independent Variable
3Total\_same\_sex\_couple\_year\_2005\_201 Independent Variable
4:Total\_adoption\_by\_each\_state. Interpolation may be neccessary
since Independent variable 1,2, and 3, are of the following years: 2005
- 2016. Variable 4 consist of the following years:
1990,2000,2001,2005,2007,2008,2009,2010,2011,2012 Linear Interpolation
$y = y\_1 + :raw-latex:`\frac{y_2 - y_1}{x_2 - x_1}`(x -x\_1) $
Dependent Variable The rate of adoption. May be theoretically computed
for missing years using interpolation for independent variable 4. ##
Miscellaneous Total number of same sex households # Documentation

Three Casual Models
-------------------

.. code:: ipython3

    Image(filename="img/CasualModel1.png",width=400,height=500)




.. image:: output_5_0.png
   :width: 400px
   :height: 500px



Having a spouse increases the chance of adoption.Income may be the
hidden factor that causes this relationship since both partners may be
bringing home income. (Income is the mediating variable)

.. code:: ipython3

    Image(filename="img/CasualModel2.jpg",width=400,height=500)




.. image:: output_7_0.jpeg
   :width: 400px
   :height: 500px



Same sex spouses adopt at a higher rate, but the only way to be spouse
it must be established by law, which means marriage must be legal in the
state one resides to be considered a "spouse".

.. code:: ipython3

    Image(filename="img/CasualModel3.jpg",width=400,height=500)




.. image:: output_9_0.jpeg
   :width: 400px
   :height: 500px



The adoption rate, variable y (independent variable) requires that x be
same sex couple as they fit the definition of LGBTQ. Total same sex
couple has a direct relationship on adoption rate, in that more same sex
couple, there are higher or lower rate.

Read In Data
------------

Saving the the data above in seperate variable. Possible variable names
are as follow independentOne, independentTwo, independent3, independent4

.. code:: ipython3

    #Using json files, option one, csv converted to json
    pathvar1 = "Income_same_sex_couple.json"
    samesexhouseholds = "samesexhouseholds.json"
    pathvar2 = "Same_sex_couple_who_are_same_sex_spouses_for_years_2005_2016.json"
    pathvar3 = "Total_same_sex_couple_year_2005_2016.json"
    pathvar4 = "Total_adoption_by_each_state.json"

.. code:: ipython3

    cd C:\Users\Ramiro Gonzalez\Desktop\POLI127DATA\csv


.. parsed-literal::

    C:\Users\Ramiro Gonzalez\Desktop\POLI127DATA\csv
    

.. code:: ipython3

    #income was originally in percentage
    #importing to csv, analysis may be easier this way. 
    pathvar1csv = "Income_same_sex_couple.csv"
    sameSexHouseholdsTcsv = "samesexhouseholdsT.csv"
    sameSexHouseholdscsv = "samesexhouseholds.csv"
    pathVar2csv = "Same_sex_couple_who_are_same_sex_spouses_for_years_2005_2016.csv"
    pathVar3csv = "Total_same_sex_couple_year_2005_2016.csv"
    pathVar4csv = "Total_adoption_by_each_state.csv"

.. code:: ipython3

    income_couples = pd.read_csv(pathvar1csv) #DONE
    same_sex_householdT = pd.read_csv(sameSexHouseholdsTcsv) #DONE
    same_sex_household = pd.read_csv(sameSexHouseholdscsv) #DONE
    same_sex_spouses = pd.read_csv(pathVar2csv) #DONE
    total_same_sex_couple = pd.read_csv(pathVar3csv)
    total_pop_each_state = pd.read_csv(pathVar4csv)

.. code:: ipython3

    income_couples.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>ID</th>
          <th>Income</th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2012.1</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>35</td>
          <td>Less than 35,000</td>
          <td>115369</td>
          <td>120245</td>
          <td>109634</td>
          <td>145320</td>
          <td>95910</td>
          <td>193751</td>
          <td>193751.04</td>
          <td>93008</td>
          <td>87195</td>
          <td>84670</td>
          <td>113042.70</td>
          <td>124778.72</td>
          <td>139849.74</td>
        </tr>
        <tr>
          <th>1</th>
          <td>49</td>
          <td>35,000 to 49,999</td>
          <td>79871</td>
          <td>85889</td>
          <td>78310</td>
          <td>72660</td>
          <td>63940</td>
          <td>96875</td>
          <td>96875.00</td>
          <td>58130</td>
          <td>58130</td>
          <td>56447</td>
          <td>75361.80</td>
          <td>85785.37</td>
          <td>101002.59</td>
        </tr>
        <tr>
          <th>2</th>
          <td>74</td>
          <td>50,000 to 74,999</td>
          <td>150867</td>
          <td>146012</td>
          <td>125296</td>
          <td>130788</td>
          <td>108698</td>
          <td>127149</td>
          <td>127149.00</td>
          <td>104634</td>
          <td>110447</td>
          <td>101605</td>
          <td>150723.60</td>
          <td>155973.40</td>
          <td>163158.03</td>
        </tr>
        <tr>
          <th>3</th>
          <td>99</td>
          <td>75,000 to 99,999</td>
          <td>133118</td>
          <td>128834</td>
          <td>117465</td>
          <td>108990</td>
          <td>89516</td>
          <td>72656</td>
          <td>72656.00</td>
          <td>87195</td>
          <td>87195</td>
          <td>84670</td>
          <td>120578.88</td>
          <td>124778.72</td>
          <td>124310.88</td>
        </tr>
        <tr>
          <th>4</th>
          <td>100</td>
          <td>100,000 or more</td>
          <td>390480</td>
          <td>360736</td>
          <td>336733</td>
          <td>254310</td>
          <td>255760</td>
          <td>96875</td>
          <td>96875.00</td>
          <td>226707</td>
          <td>220894</td>
          <td>225789</td>
          <td>278838.66</td>
          <td>265154.78</td>
          <td>233082.90</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    same_sex_spouses.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>3903</td>
          <td>4258</td>
          <td>2936</td>
          <td>2905</td>
          <td>2716</td>
          <td>1625</td>
          <td>1777</td>
          <td>1865</td>
          <td>1857</td>
          <td>4234</td>
          <td>6312</td>
          <td>5617</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1073</td>
          <td>694</td>
          <td>497</td>
          <td>171</td>
          <td>275</td>
          <td>114</td>
          <td>355</td>
          <td>194</td>
          <td>276</td>
          <td>573</td>
          <td>492</td>
          <td>527</td>
        </tr>
        <tr>
          <th>2</th>
          <td>10885</td>
          <td>7356</td>
          <td>5937</td>
          <td>3869</td>
          <td>3347</td>
          <td>2659</td>
          <td>2634</td>
          <td>2271</td>
          <td>2384</td>
          <td>7362</td>
          <td>7248</td>
          <td>6162</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2228</td>
          <td>3097</td>
          <td>2461</td>
          <td>1025</td>
          <td>1167</td>
          <td>947</td>
          <td>975</td>
          <td>1017</td>
          <td>1159</td>
          <td>3655</td>
          <td>3397</td>
          <td>4181</td>
        </tr>
        <tr>
          <th>4</th>
          <td>73920</td>
          <td>67153</td>
          <td>53336</td>
          <td>40280</td>
          <td>27679</td>
          <td>29171</td>
          <td>28897</td>
          <td>28110</td>
          <td>23377</td>
          <td>35815</td>
          <td>40992</td>
          <td>43216</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    total_same_sex_couple.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alabama</td>
          <td>7,885</td>
          <td>7,814</td>
          <td>6,797</td>
          <td>7,157</td>
          <td>6,274</td>
          <td>6,180</td>
          <td>5,452</td>
          <td>4,527</td>
          <td>4,850</td>
          <td>7,589</td>
          <td>9,594</td>
          <td>8,602</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Alaska</td>
          <td>1,952</td>
          <td>1,359</td>
          <td>1,816</td>
          <td>982</td>
          <td>1,108</td>
          <td>828</td>
          <td>752</td>
          <td>1,136</td>
          <td>854</td>
          <td>1,462</td>
          <td>1,003</td>
          <td>1,644</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Arizona</td>
          <td>20,656</td>
          <td>20,781</td>
          <td>17,515</td>
          <td>17,352</td>
          <td>17,169</td>
          <td>13,641</td>
          <td>15,143</td>
          <td>14,375</td>
          <td>12,960</td>
          <td>17,827</td>
          <td>15,164</td>
          <td>16,931</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Arkansas</td>
          <td>5,099</td>
          <td>5,501</td>
          <td>5,399</td>
          <td>4,928</td>
          <td>3,706</td>
          <td>2,526</td>
          <td>4,015</td>
          <td>3,769</td>
          <td>3,176</td>
          <td>6,228</td>
          <td>4,752</td>
          <td>5,890</td>
        </tr>
        <tr>
          <th>4</th>
          <td>California</td>
          <td>128,111</td>
          <td>120,998</td>
          <td>109,296</td>
          <td>107,991</td>
          <td>89,001</td>
          <td>87,078</td>
          <td>90,023</td>
          <td>81,954</td>
          <td>84,397</td>
          <td>104,723</td>
          <td>108,734</td>
          <td>107,772</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    total_pop_each_state.head()
    #this will be a poblem in our anaysis, 1990 - 2012, use interpolation and reorder




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>State</th>
          <th>1990</th>
          <th>2000</th>
          <th>2001</th>
          <th>2005</th>
          <th>2007</th>
          <th>2008</th>
          <th>2009</th>
          <th>2010</th>
          <th>2011</th>
          <th>2012</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alabama</td>
          <td>1,907</td>
          <td>2,009</td>
          <td>1,857</td>
          <td>2,093</td>
          <td>2,298</td>
          <td>2,252</td>
          <td>2461</td>
          <td>1813</td>
          <td>2140</td>
          <td>2590</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Alaska</td>
          <td>611</td>
          <td>634</td>
          <td>616</td>
          <td>631</td>
          <td>618</td>
          <td>643</td>
          <td>767</td>
          <td>713</td>
          <td>714</td>
          <td>699</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Arizona</td>
          <td>1,541</td>
          <td>1,736</td>
          <td>1,642</td>
          <td>1953</td>
          <td>2,491</td>
          <td>2,907</td>
          <td>2373</td>
          <td>2581</td>
          <td>2571</td>
          <td>2688</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Arkansas</td>
          <td>1,671</td>
          <td>1,907</td>
          <td>1,698</td>
          <td>2055</td>
          <td>2,014</td>
          <td>2,133</td>
          <td>2352</td>
          <td>2233</td>
          <td>2122</td>
          <td>2236</td>
        </tr>
        <tr>
          <th>4</th>
          <td>California</td>
          <td>126,082</td>
          <td>90,541</td>
          <td>9,202</td>
          <td>11034</td>
          <td>13,889</td>
          <td>12,207</td>
          <td>9982</td>
          <td>9,247</td>
          <td>7603</td>
          <td>7253</td>
        </tr>
      </tbody>
    </table>
    </div>



Obtain Summary/Descriptive Statistics
-------------------------------------

Independent Variable 1
----------------------

Income of same sex couples.

The following will be calculated for mean, sd, var, min, max, median,
range, and quantile. In my analysis of variable 1
(Income\_same\_sex\_couples) I want to find the mean, this will show the
relative income bracket smae sex couple fall into. The above "Income"
bracket is of importance here.

.. code:: ipython3

    #find the mean, for each year 
    #mean, sd, var, min, max, median, range, and quantile.
    stdDevEachYear,minEachYear,meanEachYear,maxEachYear,rangeEachYear = ({} for i in range(5))
    for i in range(5,17):
        meanEachYear[("mean{}".format(i + 2000))] = income_couples['{}'.format(i + 2000)].mean()
        stdDevEachYear[("stdDev{}".format(i + 2000))] = income_couples['{}'.format(i + 2000)].std()
        minEachYear[("min{}".format(i + 2000))] = income_couples['{}'.format(i + 2000)].min()
        maxEachYear[("max{}".format(i + 2000))] = income_couples['{}'.format(i + 2000)].max()
    print("#The mean, so called average.")
    print(meanEachYear)  
    print("#The standard deviation.")
    print(stdDevEachYear) #The standard deviation
    print("#The min and max.")
    print(minEachYear)
    print(maxEachYear)
    print("#Range is max - min.")
    for i in range(5,17):
        rangeEachYear[("range{}".format(i + 2000))] = maxEachYear[("max{}".format(i + 2000))] - minEachYear[("min{}".format(i + 2000))]
    print(rangeEachYear)
    income_couples.describe()


.. parsed-literal::

    #The mean, so called average.
    {'mean2005': 152280.828, 'mean2006': 151294.198, 'mean2007': 147709.12799999997, 'mean2008': 110636.2, 'mean2009': 112772.2, 'mean2010': 113934.8, 'mean2011': 117461.20800000001, 'mean2012': 122764.8, 'mean2013': 142413.6, 'mean2014': 153487.6, 'mean2015': 168343.2, 'mean2016': 173941.0}
    #The standard deviation.
    {'stdDev2005': 50531.16858735082, 'stdDev2006': 68344.11964062104, 'stdDev2007': 78064.05808619302, 'stdDev2008': 66382.76584099219, 'stdDev2009': 63225.561545153556, 'stdDev2010': 65328.396465090125, 'stdDev2011': 46821.68932232498, 'stdDev2012': 76112.7751510875, 'stdDev2013': 68277.20670033302, 'stdDev2014': 103978.45980923164, 'stdDev2015': 109757.43802904658, 'stdDev2016': 123862.73593175632}
    #The min and max.
    {'min2005': 101002.59, 'min2006': 85785.37, 'min2007': 75361.8, 'min2008': 56447, 'min2009': 58130, 'min2010': 58130, 'min2011': 72656.0, 'min2012': 63940, 'min2013': 72660, 'min2014': 78310, 'min2015': 85889, 'min2016': 79871}
    {'max2005': 233082.9, 'max2006': 265154.78, 'max2007': 278838.66, 'max2008': 225789, 'max2009': 220894, 'max2010': 226707, 'max2011': 193751.04, 'max2012': 255760, 'max2013': 254310, 'max2014': 336733, 'max2015': 360736, 'max2016': 390480}
    #Range is max - min.
    {'range2005': 132080.31, 'range2006': 179369.41000000003, 'range2007': 203476.86, 'range2008': 169342, 'range2009': 162764, 'range2010': 168577, 'range2011': 121095.04000000001, 'range2012': 191820, 'range2013': 181650, 'range2014': 258423, 'range2015': 274847, 'range2016': 310609}
    



.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>ID</th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2012.1</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.0000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
          <td>5.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>71.400000</td>
          <td>173941.000000</td>
          <td>168343.200000</td>
          <td>153487.600000</td>
          <td>142413.6000</td>
          <td>122764.800000</td>
          <td>117461.200000</td>
          <td>117461.208000</td>
          <td>113934.800000</td>
          <td>112772.200000</td>
          <td>110636.200000</td>
          <td>147709.128000</td>
          <td>151294.198000</td>
          <td>152280.828000</td>
        </tr>
        <tr>
          <th>std</th>
          <td>29.211299</td>
          <td>123862.735932</td>
          <td>109757.438029</td>
          <td>103978.459809</td>
          <td>68277.2067</td>
          <td>76112.775151</td>
          <td>46821.673029</td>
          <td>46821.689322</td>
          <td>65328.396465</td>
          <td>63225.561545</td>
          <td>66382.765841</td>
          <td>78064.058086</td>
          <td>68344.119641</td>
          <td>50531.168587</td>
        </tr>
        <tr>
          <th>min</th>
          <td>35.000000</td>
          <td>79871.000000</td>
          <td>85889.000000</td>
          <td>78310.000000</td>
          <td>72660.0000</td>
          <td>63940.000000</td>
          <td>72656.000000</td>
          <td>72656.000000</td>
          <td>58130.000000</td>
          <td>58130.000000</td>
          <td>56447.000000</td>
          <td>75361.800000</td>
          <td>85785.370000</td>
          <td>101002.590000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>49.000000</td>
          <td>115369.000000</td>
          <td>120245.000000</td>
          <td>109634.000000</td>
          <td>108990.0000</td>
          <td>89516.000000</td>
          <td>96875.000000</td>
          <td>96875.000000</td>
          <td>87195.000000</td>
          <td>87195.000000</td>
          <td>84670.000000</td>
          <td>113042.700000</td>
          <td>124778.720000</td>
          <td>124310.880000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>74.000000</td>
          <td>133118.000000</td>
          <td>128834.000000</td>
          <td>117465.000000</td>
          <td>130788.0000</td>
          <td>95910.000000</td>
          <td>96875.000000</td>
          <td>96875.000000</td>
          <td>93008.000000</td>
          <td>87195.000000</td>
          <td>84670.000000</td>
          <td>120578.880000</td>
          <td>124778.720000</td>
          <td>139849.740000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>99.000000</td>
          <td>150867.000000</td>
          <td>146012.000000</td>
          <td>125296.000000</td>
          <td>145320.0000</td>
          <td>108698.000000</td>
          <td>127149.000000</td>
          <td>127149.000000</td>
          <td>104634.000000</td>
          <td>110447.000000</td>
          <td>101605.000000</td>
          <td>150723.600000</td>
          <td>155973.400000</td>
          <td>163158.030000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>100.000000</td>
          <td>390480.000000</td>
          <td>360736.000000</td>
          <td>336733.000000</td>
          <td>254310.0000</td>
          <td>255760.000000</td>
          <td>193751.000000</td>
          <td>193751.040000</td>
          <td>226707.000000</td>
          <td>220894.000000</td>
          <td>225789.000000</td>
          <td>278838.660000</td>
          <td>265154.780000</td>
          <td>233082.900000</td>
        </tr>
      </tbody>
    </table>
    </div>



The above data is stored meanEachYear. We may also get the percentage of
couples that fall in the mean.

.. code:: ipython3

    meanEachYearPlotted = [] 
    for i in range(0,10):
        meanEachYearPlotted.append(meanEachYear["mean{}".format(i + 2005)])
    plt.plot(meanEachYearPlotted)
    plt.ylabel('Mean 2005 - 2016')
    #The graph below goes from 2005 - 2016 , Increment 2005 + xlabel , that is 0 is 2005, 1 is 2006 ... etc
    plt.show()



.. image:: output_25_0.png


As one can see from the above graph meanEachYearPlotted around 2009 the
average decreased dramatically, and spiked during 2016, around 2007, a
recession hit. The mean decreased dramattically.

Independent variable 2
----------------------

We consider the following. The Total Same Sex Couple Households. This
are our potential adopters.

.. code:: ipython3

    same_sex_householdT.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Year</th>
          <th>Total Households</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2005</td>
          <td>776943</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2006</td>
          <td>779867</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2007</td>
          <td>753618</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2008</td>
          <td>564473</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2009</td>
          <td>581300</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #The following describes from 2005-2016
    same_sex_householdT.describe()
    #The year portion provides very little information. 




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Year</th>
          <th>Total Households</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>12.000000</td>
          <td>12.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>2010.500000</td>
          <td>712537.416667</td>
        </tr>
        <tr>
          <th>std</th>
          <td>3.605551</td>
          <td>111898.249764</td>
        </tr>
        <tr>
          <th>min</th>
          <td>2005.000000</td>
          <td>564473.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>2007.750000</td>
          <td>602435.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>2010.500000</td>
          <td>740109.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>2013.250000</td>
          <td>780675.250000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>2016.000000</td>
          <td>887456.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #Plotting the same_sex_household 
    plt.plot(same_sex_householdT)
    plt.ylabel('Mean 2005 - 2016')
    #The graph below goes from 2005 - 2016 , Increment 2005 + xlabel , that is 0 is 2005, 1 is 2006 ... etc
    plt.show()



.. image:: output_31_0.png


Within the subset of :math:`\textbf{total households}` there exists
same\_sex\_spouses. Note that :math:`\textbf{Total households}` includes
same sex couples who are in a partnership or relationship, but also
spouses under the law. We are interested in housholds with same sex
spouses because they are more likely to adopt, or so our data will show.

.. code:: ipython3

    same_sex_spouses.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>3903</td>
          <td>4258</td>
          <td>2936</td>
          <td>2905</td>
          <td>2716</td>
          <td>1625</td>
          <td>1777</td>
          <td>1865</td>
          <td>1857</td>
          <td>4234</td>
          <td>6312</td>
          <td>5617</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1073</td>
          <td>694</td>
          <td>497</td>
          <td>171</td>
          <td>275</td>
          <td>114</td>
          <td>355</td>
          <td>194</td>
          <td>276</td>
          <td>573</td>
          <td>492</td>
          <td>527</td>
        </tr>
        <tr>
          <th>2</th>
          <td>10885</td>
          <td>7356</td>
          <td>5937</td>
          <td>3869</td>
          <td>3347</td>
          <td>2659</td>
          <td>2634</td>
          <td>2271</td>
          <td>2384</td>
          <td>7362</td>
          <td>7248</td>
          <td>6162</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2228</td>
          <td>3097</td>
          <td>2461</td>
          <td>1025</td>
          <td>1167</td>
          <td>947</td>
          <td>975</td>
          <td>1017</td>
          <td>1159</td>
          <td>3655</td>
          <td>3397</td>
          <td>4181</td>
        </tr>
        <tr>
          <th>4</th>
          <td>73920</td>
          <td>67153</td>
          <td>53336</td>
          <td>40280</td>
          <td>27679</td>
          <td>29171</td>
          <td>28897</td>
          <td>28110</td>
          <td>23377</td>
          <td>35815</td>
          <td>40992</td>
          <td>43216</td>
        </tr>
      </tbody>
    </table>
    </div>



For this to work we must remove the states, and knowing that states are
in alphabetical order Alabam = 0 .. Wyoming = 50 We will transpose the
data below, so that we are able to describe it, removing the header
manually was not possible.

originally 2010 had a missing value, recall this is same sex couples, to be retrieve from orginial data. There was missing value in orginial data, therefore interpolation may be neccesary.
============================================================================================================================================================================================

:math:`f(x) = \sum f_{j} \phi(x -x_j)` The mean would be sufficient.

.. code:: ipython3

    #Begin by storing data 
    y = [615,441,372,635,179,222,296,475,796,738,952]
    mean = []
    sumY = 0;
    for i in range(0,11):
        sumY = sumY + y[i]
    mean = sumY/12;
    print(mean)


.. parsed-literal::

    476.75
    

.. code:: ipython3

    
    total_same_sex_spouse_each_year = {};
    for i in range(16,5,-1):
        total_same_sex_spouse_each_year[('total_spouses{}'.format(2000 + i))] = same_sex_spouses['{}'.format(2000 + i)].sum()
    print(total_same_sex_spouse_each_year)


.. parsed-literal::

    {'total_spouses2016': 486978, 'total_spouses2015': 425173, 'total_spouses2014': 334901, 'total_spouses2013': 251597, 'total_spouses2012': 181961, 'total_spouses2011': 168081, 'total_spouses2010': 152746, 'total_spouses2009': 152080, 'total_spouses2008': 149917, 'total_spouses2007': 340861, 'total_spouses2006': 385682}
    

.. code:: ipython3

    same_sex_spouses.describe()
    #The descriptions are specific to entire united states, that is 51 states, for years 2016 - 2005




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.000000</td>
          <td>51.00000</td>
          <td>51.000000</td>
          <td>51.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>9548.588235</td>
          <td>8336.725490</td>
          <td>6566.686275</td>
          <td>4933.274510</td>
          <td>3567.862745</td>
          <td>3295.705882</td>
          <td>2995.019608</td>
          <td>2981.960784</td>
          <td>2939.549020</td>
          <td>6683.54902</td>
          <td>7562.392157</td>
          <td>7692.156863</td>
        </tr>
        <tr>
          <th>std</th>
          <td>12624.194422</td>
          <td>11001.608239</td>
          <td>8734.323613</td>
          <td>6803.270352</td>
          <td>4708.409409</td>
          <td>4685.072073</td>
          <td>4446.052791</td>
          <td>4305.319026</td>
          <td>3845.748886</td>
          <td>6854.02614</td>
          <td>7782.117663</td>
          <td>8116.400134</td>
        </tr>
        <tr>
          <th>min</th>
          <td>610.000000</td>
          <td>441.000000</td>
          <td>331.000000</td>
          <td>171.000000</td>
          <td>179.000000</td>
          <td>114.000000</td>
          <td>210.000000</td>
          <td>194.000000</td>
          <td>177.000000</td>
          <td>573.00000</td>
          <td>492.000000</td>
          <td>527.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>2367.000000</td>
          <td>2432.500000</td>
          <td>2140.500000</td>
          <td>1447.000000</td>
          <td>1159.000000</td>
          <td>929.000000</td>
          <td>885.000000</td>
          <td>888.500000</td>
          <td>721.000000</td>
          <td>1813.00000</td>
          <td>2150.000000</td>
          <td>2285.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>5382.000000</td>
          <td>4551.000000</td>
          <td>4161.000000</td>
          <td>2619.000000</td>
          <td>2018.000000</td>
          <td>1777.000000</td>
          <td>1716.000000</td>
          <td>1782.000000</td>
          <td>1857.000000</td>
          <td>4601.00000</td>
          <td>5231.000000</td>
          <td>5300.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>11594.000000</td>
          <td>10250.000000</td>
          <td>7671.000000</td>
          <td>5672.000000</td>
          <td>4294.500000</td>
          <td>3611.500000</td>
          <td>3239.000000</td>
          <td>3047.000000</td>
          <td>3030.500000</td>
          <td>8683.00000</td>
          <td>9597.500000</td>
          <td>10368.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>73920.000000</td>
          <td>67153.000000</td>
          <td>53336.000000</td>
          <td>40280.000000</td>
          <td>27679.000000</td>
          <td>29171.000000</td>
          <td>28897.000000</td>
          <td>28110.000000</td>
          <td>23377.000000</td>
          <td>35815.00000</td>
          <td>40992.000000</td>
          <td>43216.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



If need it be for every state we whould do the following.

.. code:: ipython3

    # we transpose it and calculate the statistics for every state, as follows. 
    (same_sex_spouses.T).describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>0</th>
          <th>1</th>
          <th>2</th>
          <th>3</th>
          <th>4</th>
          <th>5</th>
          <th>6</th>
          <th>7</th>
          <th>8</th>
          <th>9</th>
          <th>...</th>
          <th>41</th>
          <th>42</th>
          <th>43</th>
          <th>44</th>
          <th>45</th>
          <th>46</th>
          <th>47</th>
          <th>48</th>
          <th>49</th>
          <th>50</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>12.000000</td>
          <td>12.00000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>...</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
          <td>12.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>3333.750000</td>
          <td>436.75000</td>
          <td>5176.166667</td>
          <td>2109.083333</td>
          <td>40995.500000</td>
          <td>4903.666667</td>
          <td>4512.416667</td>
          <td>1119.416667</td>
          <td>1366.166667</td>
          <td>17516.333333</td>
          <td>...</td>
          <td>606.416667</td>
          <td>4989.583333</td>
          <td>18250.083333</td>
          <td>2189.833333</td>
          <td>1187.500000</td>
          <td>6892.083333</td>
          <td>7886.500000</td>
          <td>1338.666667</td>
          <td>4545.416667</td>
          <td>516.416667</td>
        </tr>
        <tr>
          <th>std</th>
          <td>1551.447953</td>
          <td>269.13806</td>
          <td>2731.183721</td>
          <td>1215.432468</td>
          <td>16216.643883</td>
          <td>3014.856467</td>
          <td>1121.090091</td>
          <td>671.995868</td>
          <td>1087.502379</td>
          <td>9446.391532</td>
          <td>...</td>
          <td>203.503611</td>
          <td>2651.329802</td>
          <td>9070.256551</td>
          <td>1138.081067</td>
          <td>537.738446</td>
          <td>3371.901499</td>
          <td>5063.629573</td>
          <td>822.887856</td>
          <td>2343.357011</td>
          <td>237.369470</td>
        </tr>
        <tr>
          <th>min</th>
          <td>1625.000000</td>
          <td>114.00000</td>
          <td>2271.000000</td>
          <td>947.000000</td>
          <td>23377.000000</td>
          <td>1843.000000</td>
          <td>2375.000000</td>
          <td>494.000000</td>
          <td>210.000000</td>
          <td>8147.000000</td>
          <td>...</td>
          <td>295.000000</td>
          <td>2060.000000</td>
          <td>8302.000000</td>
          <td>308.000000</td>
          <td>610.000000</td>
          <td>3160.000000</td>
          <td>2459.000000</td>
          <td>307.000000</td>
          <td>2053.000000</td>
          <td>179.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>1863.000000</td>
          <td>254.75000</td>
          <td>2652.750000</td>
          <td>1023.000000</td>
          <td>28700.250000</td>
          <td>2281.750000</td>
          <td>3849.750000</td>
          <td>632.000000</td>
          <td>534.500000</td>
          <td>9287.500000</td>
          <td>...</td>
          <td>435.500000</td>
          <td>2611.500000</td>
          <td>9851.500000</td>
          <td>1511.500000</td>
          <td>708.000000</td>
          <td>3806.000000</td>
          <td>2995.500000</td>
          <td>702.250000</td>
          <td>2323.750000</td>
          <td>353.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>2920.500000</td>
          <td>423.50000</td>
          <td>4903.000000</td>
          <td>1697.500000</td>
          <td>38047.500000</td>
          <td>4456.000000</td>
          <td>4714.000000</td>
          <td>912.500000</td>
          <td>1176.500000</td>
          <td>15883.500000</td>
          <td>...</td>
          <td>626.500000</td>
          <td>4156.000000</td>
          <td>17656.500000</td>
          <td>2070.500000</td>
          <td>1107.000000</td>
          <td>6470.500000</td>
          <td>7906.000000</td>
          <td>973.000000</td>
          <td>4299.500000</td>
          <td>475.500000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>4240.000000</td>
          <td>538.50000</td>
          <td>7275.000000</td>
          <td>3172.000000</td>
          <td>45746.000000</td>
          <td>6319.000000</td>
          <td>5320.500000</td>
          <td>1263.000000</td>
          <td>1918.250000</td>
          <td>22695.250000</td>
          <td>...</td>
          <td>757.250000</td>
          <td>6905.250000</td>
          <td>26116.750000</td>
          <td>3289.000000</td>
          <td>1524.750000</td>
          <td>9824.500000</td>
          <td>10946.750000</td>
          <td>2225.000000</td>
          <td>6460.250000</td>
          <td>660.750000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>6312.000000</td>
          <td>1073.00000</td>
          <td>10885.000000</td>
          <td>4181.000000</td>
          <td>73920.000000</td>
          <td>10112.000000</td>
          <td>6126.000000</td>
          <td>2324.000000</td>
          <td>3729.000000</td>
          <td>38956.000000</td>
          <td>...</td>
          <td>931.000000</td>
          <td>9667.000000</td>
          <td>34703.000000</td>
          <td>3823.000000</td>
          <td>2380.000000</td>
          <td>11885.000000</td>
          <td>17196.000000</td>
          <td>2574.000000</td>
          <td>8051.000000</td>
          <td>952.000000</td>
        </tr>
      </tbody>
    </table>
    <p>8 rows × 51 columns</p>
    </div>



Independent Variable 3
----------------------

.. code:: ipython3

    total_same_sex_couple.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alabama</td>
          <td>7,885</td>
          <td>7,814</td>
          <td>6,797</td>
          <td>7,157</td>
          <td>6,274</td>
          <td>6,180</td>
          <td>5,452</td>
          <td>4,527</td>
          <td>4,850</td>
          <td>7,589</td>
          <td>9,594</td>
          <td>8,602</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Alaska</td>
          <td>1,952</td>
          <td>1,359</td>
          <td>1,816</td>
          <td>982</td>
          <td>1,108</td>
          <td>828</td>
          <td>752</td>
          <td>1,136</td>
          <td>854</td>
          <td>1,462</td>
          <td>1,003</td>
          <td>1,644</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Arizona</td>
          <td>20,656</td>
          <td>20,781</td>
          <td>17,515</td>
          <td>17,352</td>
          <td>17,169</td>
          <td>13,641</td>
          <td>15,143</td>
          <td>14,375</td>
          <td>12,960</td>
          <td>17,827</td>
          <td>15,164</td>
          <td>16,931</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Arkansas</td>
          <td>5,099</td>
          <td>5,501</td>
          <td>5,399</td>
          <td>4,928</td>
          <td>3,706</td>
          <td>2,526</td>
          <td>4,015</td>
          <td>3,769</td>
          <td>3,176</td>
          <td>6,228</td>
          <td>4,752</td>
          <td>5,890</td>
        </tr>
        <tr>
          <th>4</th>
          <td>California</td>
          <td>128,111</td>
          <td>120,998</td>
          <td>109,296</td>
          <td>107,991</td>
          <td>89,001</td>
          <td>87,078</td>
          <td>90,023</td>
          <td>81,954</td>
          <td>84,397</td>
          <td>104,723</td>
          <td>108,734</td>
          <td>107,772</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    total_same_sex_couple.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>2016</th>
          <th>2015</th>
          <th>2014</th>
          <th>2013</th>
          <th>2012</th>
          <th>2011</th>
          <th>2010</th>
          <th>2009</th>
          <th>2008</th>
          <th>2007</th>
          <th>2006</th>
          <th>2005</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
        </tr>
        <tr>
          <th>unique</th>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>50</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
          <td>51</td>
        </tr>
        <tr>
          <th>top</th>
          <td>New Jersey</td>
          <td>1,650</td>
          <td>14,602</td>
          <td>13,140</td>
          <td>1,183</td>
          <td>1,372</td>
          <td>413</td>
          <td>6,347</td>
          <td>13,512</td>
          <td>4,820</td>
          <td>4,320</td>
          <td>6,404</td>
          <td>14,722</td>
        </tr>
        <tr>
          <th>freq</th>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



Independent variable 4
----------------------

Total adoption by each state.

.. code:: ipython3

    total_pop_each_state.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>State</th>
          <th>1990</th>
          <th>2000</th>
          <th>2001</th>
          <th>2005</th>
          <th>2007</th>
          <th>2008</th>
          <th>2009</th>
          <th>2010</th>
          <th>2011</th>
          <th>2012</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alabama</td>
          <td>1,907</td>
          <td>2,009</td>
          <td>1,857</td>
          <td>2,093</td>
          <td>2,298</td>
          <td>2,252</td>
          <td>2461</td>
          <td>1813</td>
          <td>2140</td>
          <td>2590</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Alaska</td>
          <td>611</td>
          <td>634</td>
          <td>616</td>
          <td>631</td>
          <td>618</td>
          <td>643</td>
          <td>767</td>
          <td>713</td>
          <td>714</td>
          <td>699</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Arizona</td>
          <td>1,541</td>
          <td>1,736</td>
          <td>1,642</td>
          <td>1953</td>
          <td>2,491</td>
          <td>2,907</td>
          <td>2373</td>
          <td>2581</td>
          <td>2571</td>
          <td>2688</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Arkansas</td>
          <td>1,671</td>
          <td>1,907</td>
          <td>1,698</td>
          <td>2055</td>
          <td>2,014</td>
          <td>2,133</td>
          <td>2352</td>
          <td>2233</td>
          <td>2122</td>
          <td>2236</td>
        </tr>
        <tr>
          <th>4</th>
          <td>California</td>
          <td>126,082</td>
          <td>90,541</td>
          <td>9,202</td>
          <td>11034</td>
          <td>13,889</td>
          <td>12,207</td>
          <td>9982</td>
          <td>9,247</td>
          <td>7603</td>
          <td>7253</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    (total_pop_each_state['2007']).describe()




.. parsed-literal::

    count        51
    unique       51
    top       4,973
    freq          1
    Name: 2007, dtype: object



Analysis of 2007
================

.. code:: ipython3

    path2007 = 'IIIP.csv'

.. code:: ipython3

    IIP = pd.read_csv(path2007)

.. code:: ipython3

    IIP.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>State</th>
          <th>Total Adopted</th>
          <th>Adopted Children</th>
          <th>Same Sex Spouse</th>
          <th>Same Sex Couple</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alabama</td>
          <td>24944</td>
          <td>301</td>
          <td>4234</td>
          <td>7,589</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Alaska</td>
          <td>691</td>
          <td>594</td>
          <td>573</td>
          <td>1,462</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Arizona</td>
          <td>28966</td>
          <td>543</td>
          <td>7362</td>
          <td>17,827</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Arkansas</td>
          <td>15973</td>
          <td>1040</td>
          <td>3655</td>
          <td>6,228</td>
        </tr>
        <tr>
          <th>4</th>
          <td>California</td>
          <td>167190</td>
          <td>16458</td>
          <td>35815</td>
          <td>104,723</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    independent1, independent2,independent3 = ([] for i in range(3))
    independent1 = IIP['Total Adopted']
    independent2 = IIP['Same Sex Spouse']
    independent3 = IIP['Same Sex Couple']
    dependent = IIP['Adopted Children']

Cross Tabulation
----------------

.. code:: ipython3

    pd.crosstab(dependent, [independent1, independent2, independent3], rownames=['dependent'], colnames=['independent1', 'independent2','independent3'])




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead tr th {
            text-align: left;
        }
    
        .dataframe thead tr:last-of-type th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr>
          <th>independent1</th>
          <th>100736</th>
          <th>10588</th>
          <th>110275</th>
          <th>11764</th>
          <th>11812</th>
          <th>15973</th>
          <th>16300</th>
          <th>167190</th>
          <th>18569</th>
          <th>19239</th>
          <th>...</th>
          <th>62653</th>
          <th>6803</th>
          <th>6864</th>
          <th>691</th>
          <th>6941</th>
          <th>7137</th>
          <th>73638</th>
          <th>82179</th>
          <th>9562</th>
          <th>9849</th>
        </tr>
        <tr>
          <th>independent2</th>
          <th>19491</th>
          <th>3928</th>
          <th>21921</th>
          <th>1908</th>
          <th>2187</th>
          <th>3655</th>
          <th>3344</th>
          <th>35815</th>
          <th>3478</th>
          <th>4725</th>
          <th>...</th>
          <th>12336</th>
          <th>1058</th>
          <th>1344</th>
          <th>573</th>
          <th>743</th>
          <th>1718</th>
          <th>13705</th>
          <th>21727</th>
          <th>1578</th>
          <th>2466</th>
        </tr>
        <tr>
          <th>independent3</th>
          <th>54,144</th>
          <th>7,398</th>
          <th>48,179</th>
          <th>6,059</th>
          <th>3,784</th>
          <th>6,228</th>
          <th>4,407</th>
          <th>104,723</th>
          <th>6,124</th>
          <th>9,546</th>
          <th>...</th>
          <th>24,973</th>
          <th>1,831</th>
          <th>3,643</th>
          <th>1,462</th>
          <th>2,353</th>
          <th>4,350</th>
          <th>30,524</th>
          <th>53,648</th>
          <th>2,657</th>
          <th>3,795</th>
        </tr>
        <tr>
          <th>dependent</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>95</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>161</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>176</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>183</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>235</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>248</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>257</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>279</th>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>286</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>301</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>323</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>367</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>384</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>462</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>469</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>499</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>543</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>594</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>616</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>725</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>758</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>873</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>959</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>962</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1040</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1056</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1143</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1232</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1328</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1335</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1887</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1950</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2142</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2344</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2377</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3004</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3588</th>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>5828</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>7042</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>16458</th>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>...</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>41 rows × 51 columns</p>
    </div>



.. code:: ipython3

    import matplotlib.pyplot as plt
    plt.scatter(independent1, dependent)




.. parsed-literal::

    <matplotlib.collections.PathCollection at 0x1bdd7344748>




.. image:: output_55_1.png


.. code:: ipython3

    plt.scatter(independent2, dependent)




.. parsed-literal::

    <matplotlib.collections.PathCollection at 0x1bdd74a19e8>




.. image:: output_56_1.png


.. code:: ipython3

    plt.scatter(independent3, dependent)




.. parsed-literal::

    <matplotlib.collections.PathCollection at 0x1bdd74ff780>




.. image:: output_57_1.png


.. code:: ipython3

    import numpy as np
    #np.correlate(independent1,dependent, "full")

.. code:: ipython3

    #np.correlate(independent2,dependent)

.. code:: ipython3

    #np.correlate(independent3,dependent)

.. code:: ipython3

    import statsmodels.api as sm

.. code:: ipython3

    model = sm.OLS(dependent, independent2).fit()
    predictions = model.predict(dependent) 
    model.summary()




.. raw:: html

    <table class="simpletable">
    <caption>OLS Regression Results</caption>
    <tr>
      <th>Dep. Variable:</th>    <td>Adopted Children</td> <th>  R-squared:         </th> <td>   0.698</td>
    </tr>
    <tr>
      <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.692</td>
    </tr>
    <tr>
      <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   115.6</td>
    </tr>
    <tr>
      <th>Date:</th>             <td>Wed, 24 Oct 2018</td> <th>  Prob (F-statistic):</th> <td>1.32e-14</td>
    </tr>
    <tr>
      <th>Time:</th>                 <td>00:38:40</td>     <th>  Log-Likelihood:    </th> <td> -447.55</td>
    </tr>
    <tr>
      <th>No. Observations:</th>      <td>    51</td>      <th>  AIC:               </th> <td>   897.1</td>
    </tr>
    <tr>
      <th>Df Residuals:</th>          <td>    50</td>      <th>  BIC:               </th> <td>   899.0</td>
    </tr>
    <tr>
      <th>Df Model:</th>              <td>     1</td>      <th>                     </th>     <td> </td>   
    </tr>
    <tr>
      <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
    </tr>
    </table>
    <table class="simpletable">
    <tr>
             <td></td>            <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
    </tr>
    <tr>
      <th>Same Sex Spouse</th> <td>    0.2501</td> <td>    0.023</td> <td>   10.753</td> <td> 0.000</td> <td>    0.203</td> <td>    0.297</td>
    </tr>
    </table>
    <table class="simpletable">
    <tr>
      <th>Omnibus:</th>       <td>52.703</td> <th>  Durbin-Watson:     </th> <td>   2.050</td>
    </tr>
    <tr>
      <th>Prob(Omnibus):</th> <td> 0.000</td> <th>  Jarque-Bera (JB):  </th> <td> 402.235</td>
    </tr>
    <tr>
      <th>Skew:</th>          <td> 2.458</td> <th>  Prob(JB):          </th> <td>4.53e-88</td>
    </tr>
    <tr>
      <th>Kurtosis:</th>      <td>15.850</td> <th>  Cond. No.          </th> <td>    1.00</td>
    </tr>
    </table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.


